# Modul3UI
For FRAB#6 Module 3

# Requirements
Pyqt5
  pip install PyQt5
Pyserial
  pip install pyserial
  
When not connecting with serial communication, please comment all the serial part .
